from django.shortcuts import render,redirect
from . forms import UsForm,TprofileForm,SprofileForm,AstForm,NoticeForm,LeaveForm,UploadfileForm,AddremarksForm,AttendenceForm,MarksForm
from . models import TeacherProfile,StudentProfile,AssignmentT,Addnotice,Leaveprofile,Studentupload,Addremarks,Attendence,Marks
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.
def home(request):
	return render(request,'html/home.html')

def about(request):
	return render(request,'html/about.html')

def contact(request):
	return render(request,'html/contact.html')

def register(request):
	if request.method == "POST":
		s = UsForm(request.POST)
		if s.is_valid():
			h = s.save(commit=False)
			messages.success(request,f"{h.username} User Createdd Successfully")
			h.save()
			return redirect('/lgo')
	s = UsForm()
	return render(request,'html/register.html',{'p':s})

@login_required
def profile(request):
	return render(request,'html/profile.html')
	
@login_required
def updpf(request):
	if request.user.role_type == 2:
		x = TeacherProfile.objects.all()
		mx = []
		for i in x:
			mx.append(i.tch_id)
		if request.user.id not in mx:
			if request.method == "POST":
				tch = TprofileForm(request.POST)
				if tch.is_valid():
					t = tch.save(commit=False)
					t.tstatus = 1
					t.tch_id = request.user.id 
					t.save()
					messages.warning(request,"Profile Created Successfully")
					return redirect('/pfe')
			tch = TprofileForm()
			return render(request,'html/updateprofile.html',{'t':tch})
		else:
			z = TeacherProfile.objects.get(tch_id=request.user.id)
			if request.method == "POST":
				c = TprofileForm(request.POST,instance=z)
				if c.is_valid():
					c.save()
					messages.warning(request,"Profile Updates Successfully")
					return redirect('/pfe')
			c = TprofileForm(instance=z)
			return render(request,'html/updateprofile.html',{'ty':c})

	elif request.user.role_type == 1:
		s = StudentProfile.objects.all()
		w=[]
		for i in s:
			w.append(i.std_id)
		if request.user.id not in w:
			if request.method == "POST":
				v = SprofileForm(request.POST)
				if v.is_valid():
					q = v.save(commit=False)
					q.sstatus = 1
					q.std_id = request.user.id 
					q.save()
					messages.success(request,"Profile Created Successfully")
					return redirect('/pfe')
			v = SprofileForm()
			return render(request,'html/updateprofile.html',{'g':v})
		else:
			ku = StudentProfile.objects.get(std_id=request.user.id)
			if request.method == "POST":
				bg = SprofileForm(request.POST,instance=ku)
				if bg.is_valid():
					bg.save()
					messages.info(request,'Profile Updated Successfully')
					return redirect("/pfe")
			bg = SprofileForm(instance=ku)
			return render(request,'html/updateprofile.html',{'hn':bg})
	else:
		pass 

@login_required
def tsgnlist(request):
	b = AssignmentT.objects.filter(atch_id=request.user.id)
	if request.method == "POST":
		y= AstForm(request.POST)
		if y.is_valid():
			h = y.save(commit=False)
			h.asstatus = 1
			h.atch_id = request.user.id
			h.save()
			return redirect('/tasgn')
	y = AstForm()
	return render(request,'html/taslist.html',{'e':y,'p':b})
	
@login_required
def astup(request,v):
	y = AssignmentT.objects.get(id=v)
	if request.method == "POST":
		d = AstForm(request.POST,instance=y)
		if d.is_valid():
			d.save()
			return redirect('/tasgn')
	d = AstForm(instance=y)
	return render(request,'html/astupdate.html',{'r':d})

@login_required
def adlt(request,g):
	n = AssignmentT.objects.get(id=g)
	if request.method == "POST":
		n.delete()
		return redirect('/tasgn')
	return render(request,'html/asdel.html',{'k':n})

@login_required
def staslist(request):
	p = AssignmentT.objects.filter(asclass=request.user.studentprofile.sclass)
	return render(request,'html/staslist.html',{'e':p})

@login_required
def astt(request,h):
	j = AssignmentT.objects.get(id=h)
	return render(request,'html/asact.html',{'c':j})

@login_required
def notice(request):
	pq = Addnotice.objects.filter(nk_id=request.user.id)
	if request.method == "POST":
		u = NoticeForm(request.POST)
		if u.is_valid():
			a = u.save(commit=False)
			a.nk_id=request.user.id
			a.save()
	u = NoticeForm()
	return render(request,'html/addnotice.html',{'tl':u,'vl':pq})

@login_required
def viewnotice(request):
	b = Addnotice.objects.all()
	return render(request,'html/viewnoticee.html',{'g':b})

@login_required
def leave(request):
	z = Leaveprofile.objects.filter(slv_id=request.user.id)
	if request.method == "POST":
		lv = LeaveForm(request.POST)
		if lv.is_valid():
			f = lv.save(commit=False)
			f.slv_id=request.user.id
			f.save()
	lv = LeaveForm()
	return render(request,'html/leave.html',{'l':lv,'k':z})

@login_required
def viewleaves(request):
	e = Leaveprofile.objects.filter(tchname=request.user.username)
	return render(request,'html/viewleaves.html',{'pl':e})

@login_required
def approve(request,y):
	q = Leaveprofile.objects.get(id=y)
	if request.method=="POST":
		q.lstatus="approved"
		q.save()
		return redirect('/vl')
	return render(request,'html/approveleave.html',{'apr':q})

@login_required
def reject(request,x):
	w = Leaveprofile.objects.get(id=x)
	if request.method=="POST":
		w.lstatus="rejected"
		w.save()
		return redirect('/vl')
	return render(request,'html/rejectleave.html',{'arj':w})

@login_required
def delnotice(request,g):
	ab = Addnotice.objects.get(id=g)
	if request.method == "POST":
		ab.delete()
		return redirect('/addnt')
	return render(request,'html/noticedelete.html',{'gh':ab})

@login_required
def deleteleave(request,m):
	cd = Leaveprofile.objects.get(id=m)
	if request.method == "POST":
		cd.delete()
		return redirect('/lf')
	return render(request,'html/deleteleave.html',{'ij':cd})

@login_required
def uploadfile(request):
	po= Studentupload.objects.filter(stup_id=request.user.id)
	if request.method == 'POST':
		form= UploadfileForm(request.POST,request.FILES)
		if form.is_valid():
			z=form.save(commit=False)
			z.stup_id = request.user.id
			z.save()
			return redirect('/')
	form = UploadfileForm()
	return render(request,'html/uploadfile.html',{'form':form,'fd':po})

@login_required
def viewasssub(request):
	st = Studentupload.objects.all()
	return render(request,'html/viewasssub.html',{'stu':st})

@login_required
def asssubmission(request,l):
	sv= Studentupload.objects.filter(id=l)
	return render(request,'html/viewasssubmission.html',{'vs':sv})

@login_required
def assremarks(request):
	vw = Addremarks.objects.filter(key_id=request.user.id)
	if request.method == "POST":
		arev = AddremarksForm(request.POST)
		if arev.is_valid():
			r = arev.save(commit=False)
			r.key_id = request.user.id
			r.save()
			return redirect('/vas')
	arev = AddremarksForm()
	return render(request,'html/assremarks.html',{'aa':arev,'wv':vw})


def vsubasstatus(request):
	re = Addremarks.objects.all()
	return render(request,'html/viewsubassignstatus.html',{'ty':re})

def addattendence(request):	
	q = Attendence.objects.all()
	if request.method == "POST":
		k= AttendenceForm(request.POST)
		if k.is_valid():
			h = k.save(commit=False)	
			h.save()
			return redirect('/adat')
	k= AttendenceForm()
	return render(request,'html/addattendence.html',{'s':k,'f':q})


def viewattendence(request):
	o = Attendence.objects.filter(eid=request.user.eid)
	return render(request,'html/viewattendence.html',{'y':o})

def attendenceupdate(request,w):
	u = Attendence.objects.get(id=w)
	if request.method == "POST":
		n = AttendenceForm(request.POST,instance=u)
		if n.is_valid():
			n.save()
			return redirect('/adat')
	n = AttendenceForm(instance=u)
	return render(request,'html/attendenceupdate.html',{'h':n})

def addmarks(request):
	jk = Marks.objects.all()
	if request.method == "POST":
		gh = MarksForm(request.POST)
		if gh.is_valid():
			h = gh.save(commit=False)	
			h.save()
			return redirect('/adm')
	gh= MarksForm()
	return render(request,'html/addmarks.html',{'m':gh,'q':jk})


def marksupdate(request,lz):
	fg = Marks.objects.get(id=lz)
	if request.method == "POST":
		iu = MarksForm(request.POST,instance=fg)
		if iu.is_valid():
			iu.save()
			return redirect('/adm')
	iu = MarksForm(instance=fg)
	return render(request,'html/marksupdate.html',{'op':iu})


def viewmarks(request):
	po = Marks.objects.filter(eid=request.user.eid)
	return render(request,'html/viewmarks.html',{'uy':po})


























@login_required
def assremarksedit(request,y):
	yy = Addremarks.objects.get(id=y)
	if request.method == "POST":
		ed = AddremarksForm(request.POST,instance=yy)
		if ed.is_valid():
			ed.save()
			return redirect('/vas')
	ed = AddremarksForm(instance=yy)
	return render(request,'html/assremarksedit.html',{'rr':ed})


