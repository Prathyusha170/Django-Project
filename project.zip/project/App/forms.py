from django import forms
from . models import User,TeacherProfile,StudentProfile,AssignmentT,Addnotice,Leaveprofile,Studentupload,Addremarks,Attendence,Marks
from django.contrib.auth.forms import UserCreationForm

class UsForm(UserCreationForm):
	password1 = forms.CharField(widget=forms.PasswordInput(attrs={"class":"form-control my-2","placeholder":"Enter Password"}))
	password2 = forms.CharField(widget=forms.PasswordInput(attrs={"class":"form-control my-2","placeholder":"Enter Confirm Password"}))
	class Meta:
		model = User
		fields = ["username","eid"]
		widgets = {
		"username":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Username",
			}),
		"eid":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Unique Id",
			}),
		}

class TprofileForm(forms.ModelForm):
	class Meta:
		model = TeacherProfile
		fields = ["tage",'tgr','tsubject','texperience','tdesg',]
		widgets = {
		"tage":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your age",
			}),
		"tgr":forms.Select(attrs={
			"class":"form-control my-2",
			}),
		"tsubject":forms.Select(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your Subject",
			}),
		"texperience":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your Experience",
			}),
		"tdesg":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your Designation",
			}),
		}

class SprofileForm(forms.ModelForm):
	class Meta:
		model = StudentProfile
		fields = ["sage",'sgr','sclass',]
		widgets = {
		"sage":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your age",
			}),
		"sgr":forms.Select(attrs={
			"class":"form-control my-2",
			}),
		"sclass":forms.Select(attrs={
			"class":"form-control my-2",
			}),
		}

class AstForm(forms.ModelForm):
	class Meta:
		model = AssignmentT
		fields = ["asnum",'asname','asclass','assubject','asstartdate','asenddate','asmarks','asdesc','asstatus']
		widgets = {
		"asnum":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Assgn Number",
			}),
		"asname":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Assgn Name",
			}),
		"asclass":forms.Select(attrs={
			"class":"form-control my-2",
			}),
		"assubject":forms.Select(attrs={
			"class":"form-control my-2",
			}),
		"asstartdate":forms.TextInput(attrs={
			"class":"form-control my-2",
			"type":"date",
			}),
		"asenddate":forms.TextInput(attrs={
			"class":"form-control my-2",
			"type":"date",
			}),
		"asmarks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			}),
		"asdesc":forms.Textarea(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Assgn description",
			"rows":5,
			}),

		}

class NoticeForm(forms.ModelForm):
	class Meta:
		model = Addnotice
		fields = ["noticee",]
		widgets ={
		"noticee":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Notice",
			}),
		}	

class LeaveForm(forms.ModelForm):
	class Meta:
		model = Leaveprofile
		fields = ["sid",'sname','sclass','tchname','lreason','lsdate','ledate',]
		widgets ={
		"sid":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your id",
			}),
		"sname":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your name",
			}),
		"sclass":forms.Select(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your class",
			}),
		"tchname":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter classteacher name",
			}),
		"lreason":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Your reason for leave",
			}),
		"lsdate":forms.TextInput(attrs={
			"class":"form-control my-2",
			"type":"date",
			}),
		"ledate":forms.TextInput(attrs={
			"class":"form-control my-2",
			"type":"date",
			}),

		}

class UploadfileForm(forms.ModelForm):
	class Meta:
		model = Studentupload
		fields = ['uploadfile']

class AddremarksForm(forms.ModelForm):
	class Meta:
		model = Addremarks
		fields = ["marks",'remarks','asstatus']
		widgets ={
		"marks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter marks",
			}),
		"remarks":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Remarks",
			}),
		"asstatus":forms.Select(attrs={
			"class":"form-control my-2",
			})
		}

class AttendenceForm(forms.ModelForm):
	class Meta:
		model = Attendence
		fields = ["username","eid","daysattended","totaldays"]
		widgets={
		"username":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter student Name",
			}),
		"eid":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Student Number",
			}),
		"daysattended":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"No.of Days Attended",
			}),
		"totaldays":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Total Days",
			}),
		}
class MarksForm(forms.ModelForm):
	class Meta:
		model = Marks
		fields = ["username","eid","exam","totalmarksofeachsubject","telugumarks","hindimarks","englishmarks","mathsmarks","sciencemarks","socialmarks"]
		widgets={
		"username":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter student Name",
			}),
		"eid":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Student Number",
			}),
		"exam":forms.TextInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Exam",
			}),
		"totalmarksofeachsubject":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Total Marks of each Subject",
			}),
		"telugumarks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Telugu marks",
			}),
		"hindimarks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Hindi marks",
			}),
		"englishmarks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter English marks",
			}),
		"mathsmarks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Maths marks",
			}),
		"sciencemarks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Science marks",
			}),
		"socialmarks":forms.NumberInput(attrs={
			"class":"form-control my-2",
			"placeholder":"Enter Social marks",
			}),

		}