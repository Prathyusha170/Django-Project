from django.urls import path
from App import views
from django.contrib.auth import views as ad

urlpatterns=[
    path('',views.home,name="hm"),
	path('ab/',views.about,name="abt"),
	path('ct/',views.contact,name="cnt"),
	path('reg/',views.register,name="rg"),
	path('lgo/',ad.LoginView.as_view(template_name='html/login.html'),name="lg"),
	path('lgot/',ad.LogoutView.as_view(template_name='html/logout.html'),name="lgto"),
    path('pfe/',views.profile,name="pf"),
    path('upf/',views.updpf,name="upfe"),
    path('tasgn/',views.tsgnlist,name="taslist"),
    path('tas/<int:v>/',views.astup,name="atup"),
    path('tchdl/<int:g>/',views.adlt,name="atdh"),
    path('stlist/',views.staslist,name="stas"),
    path('ast/<int:h>',views.astt,name="asty"),
    path('addnt/',views.notice,name="an"),
    path('vnt/',views.viewnotice,name="vn"),
    path('lf/',views.leave,name="lefr"),
    path('vl/',views.viewleaves,name="levie"),
    path('vappr/<int:y>/',views.approve,name="vp"),
    path('vreject/<int:x>/',views.reject,name="vr"),
    path('nd/<int:g>/',views.delnotice,name="nd"),
    path('dell/<int:m>/',views.deleteleave,name="dl"),
    path('uplf/',views.uploadfile,name="uplfi"),
    path('vas/',views.viewasssub,name="vasm"),
    path('vpsb/<int:l>/',views.asssubmission,name="vassub"),
    path('adre/',views.assremarks,name="asr"),
    path('adree/<int:y>',views.assremarksedit,name="asd"),
    path('vsft/',views.vsubasstatus,name="vsas"),
    path('adat/',views.addattendence,name="adatt"),
    path('vat/',views.viewattendence,name="vatt"),
    path('attup/<int:w>',views.attendenceupdate,name="attupd"),
    path('adm/',views.addmarks,name="adma"),
    path('mup/<int:lz>',views.marksupdate,name="maup"),
    path('vm/',views.viewmarks,name="vma"),


]


