from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class User(AbstractUser):
	rt = [
	    (0,'Guest'),
	    (1,'Student'),
	    (2,'teacher')
	]
	eid = models.CharField(max_length=20) 
	role_type = models.IntegerField(default=0)

class TeacherProfile(models.Model):
	g = [
	   ("k","Select Your Gender"),
	   ('M',"Male"),
	   ("F","Female"),
	]
	s = [
       ('0','-----Select Subject-----'),
       ('1','Telugu'),
       ('2','Hindi'),
       ('3','English'),
       ('4','Maths'),
       ('5','Science'),
       ('6','Social'),
    ]

	tage = models.IntegerField()
	tgr = models.CharField(max_length=5,default='k',choices=g)
	tsubject = models.CharField(max_length=12,default=0,choices=s)
	texperience = models.IntegerField()
	tdesg = models.CharField(max_length=50)
	tstatus = models.BooleanField(default=0)
	tch = models.OneToOneField(User,on_delete=models.CASCADE)

class StudentProfile(models.Model):
	sg = [
		("h","Select Your Gender"),
		('M',"Male"),
		("F","Female")
	  ]
	c = [
	   ('G','-----Select Class-----'),
	   ('1','1st class'),
	   ('2','2nd class'),
	   ('3','3rd class'),
	   ('4','4th class'),
	   ('5','5th class'),
	   ('6','6th class'),
	   ('7','7th class'),
	   ('8','8th class'),
	   ('9','9th class'),
	   ('10','10th class'),
	]
	sage = models.IntegerField()
	sgr = models.CharField(max_length=5,default='h',choices=sg)
	sclass = models.CharField(max_length=6,default='G',choices=c)
	sstatus = models.BooleanField(default=0)
	std = models.OneToOneField(User,on_delete=models.CASCADE)


class AssignmentT(models.Model):
	c = [
	   ('G','-----Select Class-----'),
	   ('1','1st class'),
	   ('2','2nd class'),
	   ('3','3rd class'),
	   ('4','4th class'),
	   ('5','5th class'),
	   ('6','6th class'),
	   ('7','7th class'),
	   ('8','8th class'),
	   ('9','9th class'),
	   ('10','10th class'),
	]

	s = [
       ('0','-----Select Subject-----'),
       ('Telugu','Telugu'),
       ('Hindi','Hindi'),
       ('English','English'),
       ('Maths','Maths'),
       ('Science','Science'),
       ('Social','Social'),
    ]
	asnum = models.IntegerField()
	asname = models.CharField(max_length=70)
	asclass = models.CharField(default='G',max_length=50,choices=c)
	assubject = models.CharField(default='0',max_length=50,choices=s)
	asdesc = models.CharField(max_length=250)
	asstartdate = models.DateField()
	asenddate = models.DateField()
	asmarks = models.IntegerField(default=10)
	asstatus = models.BooleanField(default=0)
	atch = models.ForeignKey(User,on_delete=models.CASCADE)

class Addnotice(models.Model):
	noticee	= models.CharField(max_length=500)
	datime = models.DateTimeField(auto_now_add=True)
	nk = models.ForeignKey(User,on_delete=models.CASCADE)



class Leaveprofile(models.Model):
	c = [
	   ('G','-----Select Class-----'),
	   ('1','1st class'),
	   ('2','2nd class'),
	   ('3','3rd class'),
	   ('4','4th class'),
	   ('5','5th class'),
	   ('6','6th class'),
	   ('7','7th class'),
	   ('8','8th class'),
	   ('9','9th class'),
	   ('10','10th class'),
	]
	a=[
	  ('pending','pending'),
	  ('approved','approved'),
	  ('rejected','rejected')
	]
	sid = models.CharField(max_length=10)
	sname = models.CharField(max_length=50)
	sclass = models.CharField(default='G',max_length=50,choices=c)
	tchname = models.CharField(max_length=50)
	lreason = models.CharField(max_length=500)
	lsdate = models.DateField()
	ledate = models.DateField()
	slv = models.ForeignKey(User,on_delete=models.CASCADE)
	lstatus = models.CharField(default='pending',max_length=50,choices=a)
	dati = models.DateTimeField(auto_now_add=True)

class Studentupload(models.Model):
	uploadfile=models.FileField(upload_to=None)
	uploadtime=models.DateTimeField(auto_now_add=True)
	stup=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
	ass = models.ForeignKey(AssignmentT,on_delete=models.CASCADE,null=True)

class Addremarks(models.Model):
	x= [
	   ('pending','pending'),
	   ('assapproved','assapproved'),
	   ('asrejected','assrejected')
	]
	marks = models.IntegerField()
	remarks = models.CharField(max_length=100)
	asstatus = models.CharField(default='pending',max_length=100,choices=x)
	key = models.ForeignKey(User,on_delete=models.CASCADE,null=True)

class Attendence(models.Model):
	username=models.CharField(max_length=60)
	eid=models.CharField(max_length=15)
	daysattended=models.IntegerField()
	totaldays=models.IntegerField()

class Marks(models.Model):
	username=models.CharField(max_length=90)
	eid=models.CharField(max_length=10)
	exam=models.CharField(max_length=50)
	totalmarksofeachsubject=models.IntegerField()
	telugumarks=models.IntegerField()
	hindimarks=models.IntegerField()
	englishmarks=models.IntegerField()
	mathsmarks=models.IntegerField()
	sciencemarks=models.IntegerField()
	socialmarks=models.IntegerField()



	

