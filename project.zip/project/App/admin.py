from django.contrib import admin
from . models import* 

# Register your models here.

admin.site.register(User)
admin.site.register(Leaveprofile)
admin.site.register(Studentupload)
admin.site.register(Addremarks)
